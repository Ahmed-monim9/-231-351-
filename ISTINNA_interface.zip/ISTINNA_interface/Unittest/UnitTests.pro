QT += testlib sql network
QT -= gui

CONFIG += qt console warn_on depend_includepath testcase
CONFIG -= app_bundle

TEMPLATE = app

SOURCES += \
tst_funcforserver_test.cpp \
    C:\Users\vertk\Downloads\ISTINNA_interface\Server\task1.cpp


HEADERS += \
    C:\Users\vertk\Downloads\ISTINNA_interface\Server\task1.h

